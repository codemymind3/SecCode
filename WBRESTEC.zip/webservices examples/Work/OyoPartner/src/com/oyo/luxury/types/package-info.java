@javax.xml.bind.annotation.XmlSchema(namespace = "http://oyo.com/luxury/types")
package com.oyo.luxury.types;
