
/**
 * OyoEndpointServicesSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.2  Built on : Apr 17, 2012 (05:33:49 IST)
 */
package com.oyo.luxury.services;

/**
 * OyoEndpointServicesSkeletonInterface java skeleton interface for the
 * axisService
 */
public interface OyoEndpointServicesSkeletonInterface {

	/**
	 * Auto generated method signature
	 * 
	 * @param checkIn
	 * @throws AccomodationFault
	 *             :
	 */

	public com.oyo.luxury.types.Receipt bookAccomodation(com.oyo.luxury.types.CheckIn checkIn) throws AccomodationFault;

}
