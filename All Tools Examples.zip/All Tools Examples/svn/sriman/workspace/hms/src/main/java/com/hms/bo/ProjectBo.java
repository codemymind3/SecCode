package com.hms.bo;

public class ProjectBo {
	protected final long serialVersionUID=1L;
	protected int projectNo;
        protected float budget;
        protected int duration;
        protected String title;
        protected String description;
	
}
