package com.hms.bo;

public class ProjectBo {
	protected int projectNo;
	
}
