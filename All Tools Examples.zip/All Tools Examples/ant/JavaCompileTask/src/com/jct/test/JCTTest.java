package com.jct.test;

public class JCTTest {
	public static void main(String[] args) {
		System.out.println("Compiled By Ant!");
	}
}
