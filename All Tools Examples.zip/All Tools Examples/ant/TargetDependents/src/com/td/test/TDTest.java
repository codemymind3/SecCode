package com.td.test;

public class TDTest {
	public static void main(String[] args) {
		System.out.println("Target dependencies made easy!");
	}
}
