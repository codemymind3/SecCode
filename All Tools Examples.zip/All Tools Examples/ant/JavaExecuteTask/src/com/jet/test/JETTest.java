package com.jet.test;

public class JETTest {
	public static void main(String[] args) {
		System.out.println("Executed By Ant!");
	}

}
