package com.var.test;

public class VarTest {
	public static void main(String[] args) {
		System.out.println("Huray Variables!");
	}
}
