package com.pt.test;

public class PkgTest {
	public static void main(String[] args) {
		System.out.println("packaged by Ant!");
	}
}
