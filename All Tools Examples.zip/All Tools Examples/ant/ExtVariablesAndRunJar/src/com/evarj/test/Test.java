package com.evarj.test;

public class Test {
	public static void main(String[] args) {
		System.out.println("executing out of a Jar using Ant!");
	}
}
