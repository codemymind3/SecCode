package com.junit3.util;

public class Calculator {
	public int add(int a, int b) {
		return a + b;
	}
}
