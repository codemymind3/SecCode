package com.fp.test;

import com.fp.insurance.desk.YashodaHelpDesk;

public class FPTest {
	public static void main(String[] args) {
		YashodaHelpDesk yhd = new YashodaHelpDesk();
		yhd.preApproval("athena", "heart", "h394");
	}
}
