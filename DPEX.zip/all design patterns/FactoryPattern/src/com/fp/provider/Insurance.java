package com.fp.provider;

public interface Insurance {
	void submitAuthorization(String operation, String cardNo);
}
