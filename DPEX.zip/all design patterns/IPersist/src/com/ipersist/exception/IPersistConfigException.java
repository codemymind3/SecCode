package com.ipersist.exception;

public class IPersistConfigException extends RuntimeException {

	public IPersistConfigException(String message, Throwable cause) {
		super(message, cause);
	}

}
