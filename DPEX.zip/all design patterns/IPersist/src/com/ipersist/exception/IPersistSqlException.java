package com.ipersist.exception;

public class IPersistSqlException extends RuntimeException {

	public IPersistSqlException(String message, Throwable cause) {
		super(message, cause);
	}

}
