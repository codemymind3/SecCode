package com.picasa.helper;

public interface ImageService {
	byte[] getImage(Integer imageId);
}
