package com.freecharge.agent;

public interface DTHRechargeAgent {
	float rechargePackage(String accountNo, String pkg, float amount);
}
