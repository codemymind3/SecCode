package org.stackspace.webfaces.metadata;

public class ForwardMetadata {
	protected String outcome;
	protected String page;

	public String getOutcome() {
		return outcome;
	}

	public void setOutcome(String outcome) {
		this.outcome = outcome;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

}
