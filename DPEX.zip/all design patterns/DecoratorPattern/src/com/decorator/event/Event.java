package com.decorator.event;

import java.util.Date;

public interface Event {
	void organize(String place, Date eDate, int noOfParticipants);
}
