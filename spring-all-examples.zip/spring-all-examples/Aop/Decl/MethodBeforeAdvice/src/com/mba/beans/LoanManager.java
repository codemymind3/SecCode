package com.mba.beans;

public class LoanManager {
	public boolean approveLoan(String loanNo) {
		return true;
	}
}
