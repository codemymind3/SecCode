package com.mrt.beans;

public class ManageSubscriber {
	public void recharge(String mobileNumber, float amount) {
		System.out.println("recharged mobile : " + mobileNumber + " with value : " + amount);
	}
}
