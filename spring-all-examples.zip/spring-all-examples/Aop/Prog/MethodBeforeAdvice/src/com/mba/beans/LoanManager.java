package com.mba.beans;

public class LoanManager {
	public boolean approveLoan(String loanNo) {
		System.out.println("evaluating loan application with loanNo : " + loanNo);
		return true;
	}
}
