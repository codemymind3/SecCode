package com.mba.beans;

import org.springframework.stereotype.Component;

@Component
public class LoanManager {
	public boolean approveLoan(String loanNo) {
		return true;
	}
}
