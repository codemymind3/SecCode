package com.hms.exec;
public class HMSRunner {
  public static void main(String[] args) {
    System.out.println("am running out of executable jar");
  }
}