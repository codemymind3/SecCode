package com.ext.cl;
public class Runner {
  public static void main(String[] args) {
    System.out.println("hurray! am running");
  }
}