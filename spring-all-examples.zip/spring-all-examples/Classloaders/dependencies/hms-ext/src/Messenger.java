package com.hmsext.dep;
public class Messenger {
  public String getMessage() {
    return "message from ext hms application";
  }
}