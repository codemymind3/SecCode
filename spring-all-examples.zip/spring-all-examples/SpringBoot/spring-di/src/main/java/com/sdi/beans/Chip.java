package com.sdi.beans;

public class Chip {
	public void showShip() {
		System.out.println("i am chip");
	}
}
