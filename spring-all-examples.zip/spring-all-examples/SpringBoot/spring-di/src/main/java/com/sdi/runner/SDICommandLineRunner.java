package com.sdi.runner;

import org.springframework.boot.CommandLineRunner;

public class SDICommandLineRunner implements CommandLineRunner {
	@Override
	public void run(String... arg0) throws Exception {
		System.out.println("commandLineRunner");
	}

}
