package com.ai.beans;

public interface IReceiver {
	void tune(int frequency);

	String receive();
}
