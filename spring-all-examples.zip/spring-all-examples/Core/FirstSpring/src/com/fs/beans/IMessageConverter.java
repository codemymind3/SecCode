package com.fs.beans;

public interface IMessageConverter {
	String convert(String message);
}
