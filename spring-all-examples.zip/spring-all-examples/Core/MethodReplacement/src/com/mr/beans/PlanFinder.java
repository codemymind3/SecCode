package com.mr.beans;

// production application is running with this logic
public class PlanFinder {
	public String[] findPlans(int age, int zipCode, String gender, int networkType, int coverageType, int copay) {
		return new String[] { "plan1", "plan2" };
	}
}
