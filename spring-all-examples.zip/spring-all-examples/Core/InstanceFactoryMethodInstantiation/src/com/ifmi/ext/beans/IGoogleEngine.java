package com.ifmi.ext.beans;

public interface IGoogleEngine {
	String[] getDirections(String source, String destination);
}
