package com.sdp.beans;

public interface IMessageConverter {
	String convert(String message);
}
