package com.jc.annon;

public class Radio {
	public void listen() {
		System.out.println("listening...");
	}
}
