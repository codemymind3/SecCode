package com.jcaw.annon;

public class Chip {
	public void process() {
		System.out.println("processing...");
	}
}
