package com.bs.beans;

public class Toy {
	public void play() {
		System.out.println("playing...");
	}
}
