package com.dt.exception;

public class CreateJobFailedException extends Exception {

	public CreateJobFailedException(String message, Throwable cause) {
		super(message, cause);
	}

}
