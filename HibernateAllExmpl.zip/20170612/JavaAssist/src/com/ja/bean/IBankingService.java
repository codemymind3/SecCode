package com.ja.bean;

public interface IBankingService {
	double getBalance(String accountNo);
}
